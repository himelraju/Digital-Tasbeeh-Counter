package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.lang.annotation.Annotation;

public class MainActivity extends AppCompatActivity {

    TextView display;
    ImageView minus, reset, plus;
    int tajbih =0;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);
        minus = findViewById(R.id.minus);
        plus = findViewById(R.id.plus);
        reset = findViewById(R.id.reset);

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tajbih--;
                display.setText(""+tajbih);
            }
        });

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tajbih++;
                display.setText(""+tajbih);
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tajbih =0;
                display.setText(""+tajbih);
            }
        });


    }


}